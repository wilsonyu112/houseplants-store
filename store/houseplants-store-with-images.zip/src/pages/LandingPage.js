import { Link } from 'react-router-dom';

function LandingPage() {
  return (
    <div className="landing" style={{ backgroundImage: 'url("/images/landing-bg.jpg")' }}>
      <h1>Welcome to GreenLife Houseplants</h1>
      <p>
        At GreenLife, we bring you vibrant and easy-to-care houseplants to
        brighten your space and improve your wellbeing.
      </p>
      <Link to="/products">
        <button className="btn">Get Started</button>
      </Link>
    </div>
  );
}

export default LandingPage;
