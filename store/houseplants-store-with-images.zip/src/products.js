const products = [
  { id: 1, name: 'Monstera', price: 15, image: '/images/monstera.jpg', category: 'Low Light' },
  { id: 2, name: 'Snake Plant', price: 12, image: '/images/snakeplant.jpg', category: 'Air Purifying' },
  { id: 3, name: 'Aloe Vera', price: 10, image: '/images/aloe.jpg', category: 'Succulents' },
  { id: 4, name: 'Peace Lily', price: 18, image: '/images/peacelily.jpg', category: 'Air Purifying' },
  { id: 5, name: 'Fiddle Leaf Fig', price: 25, image: '/images/fiddleleaf.jpg', category: 'Low Light' },
  { id: 6, name: 'Succulent', price: 8, image: '/images/succulent.jpg', category: 'Succulents' },
];

export default products;
